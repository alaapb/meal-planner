function Home() {
    return (
        <div>
            <h1>Welcome To My Final Project</h1>
            <h2>Meal Planner</h2>
            <p>Helps user create a weekly plan for what they want to cook with the recipes and instructions required to make the meal</p>
            <img src="Meal-Planning.jpeg"/>
        </div>
    )
}

export default Home;