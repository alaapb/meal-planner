function Calendar() {
    return (
        <h1>Calendar</h1>
    )
}

export default Calendar;